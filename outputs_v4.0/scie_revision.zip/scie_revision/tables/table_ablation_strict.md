# Strict Ablation

Strict no-leakage ablation comparison.

| variant | modules_included | mae_mean | mae_std | rmse_mean | rmse_std | smape_mean | smape_std | mase_mean | directional_accuracy_mean | n_tokens | n_seeds | significance_vs_previous_variant | holm_p_value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| V0 | price-only LSTM | 4.0539 | 72.7783 | 4.7381 | 83.9381 | 153.2313 | 56.0901 | 45.6521 | 0.4202 | 200 | 3 |  | nan |
| V1 | V0 + sentiment fusion | 0.6981 | 10.2989 | 0.7186 | 10.4596 | 173.4881 | 44.1707 | 21.1029 | 0.5812 | 200 | 3 | V0 | 0.0000 |
| V2 | V1 + risk-aware graph + MIS support diversification | 0.3005 | 3.9171 | 0.3082 | 3.9893 | 64.5517 | 33.8950 | 4.4816 | 0.2918 | 200 | 3 | V1 | 0.0000 |
| V3 | V2 + MAML adaptation / full PRISM | 0.1231 | 1.5192 | 0.1479 | 1.8150 | 53.9325 | 29.4097 | 5.6618 | 0.4893 | 200 | 3 | V2 | 0.0000 |