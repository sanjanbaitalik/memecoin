# Revised Main Comparison

Paper-ready comparison table across classical, neural, and PRISM baselines.

| model | mae_mean | mae_std | mae_median | rmse_mean | mape_mean | smape_mean | roi_mean | n_tokens | model_label | actual_backend | fallback_used | model_display | rank_mae | rank_rmse | mase_mean | directional_accuracy_mean | directional_accuracy_std | rmse_std | smape_std |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| prophet | 0.0882 | 0.8809 | 0.0006 | 0.1028 | 94.2113 | 59.6737 | 0.0438 | 200 | prophet | prophet | FALSE | prophet | 1 | 1 | 2.7580 | 0.5829 | 0.2511 | nan | nan |
| persistence | 0.1056 | 1.3812 | 0.0003 | 0.1303 | 22.1193 | 18.0161 | 0.0000 | 200 | persistence | naive_last_value | FALSE | persistence | 2 | 2 | 1.0902 | 0.0412 | 0.1685 | nan | nan |
| PRISM | 0.1231 | 1.5205 | 0.0009 | 0.1479 | 95.6818 | 53.9325 | 0.0002 | 200 | PRISM | prism_v3 | FALSE | PRISM | 3 | 3 | nan | nan | nan | nan | nan |
| random_forest | 0.2619 | 3.3923 | 0.0006 | 0.2792 | 75.8636 | 43.7434 | -0.0251 | 200 | random_forest | sklearn_random_forest | FALSE | random_forest | 4 | 4 | 2.8166 | 0.3529 | 0.1992 | nan | nan |
| arima | 0.3140 | 4.0485 | 0.0007 | 0.3283 | 126.4308 | 42.8212 | -0.0164 | 200 | arima | statsmodels_arima | FALSE | arima | 5 | 5 | 9.0914 | 0.3641 | 0.1985 | nan | nan |
| xgboost | 0.3719 | 4.9336 | 0.0007 | 0.3952 | 101.2789 | 52.7485 | -0.0289 | 200 | xgboost | xgboost_xgbregressor | FALSE | xgboost | 6 | 6 | 3.5817 | 0.3318 | 0.1981 | nan | nan |
| gru | 0.3964 | 4.3570 | 0.0358 | 0.4165 | 23440488.0049 | 169.9409 | -0.0131 | 200 | gru | sklearn_mlp_gru_surrogate | TRUE | gru (fallback) | 7 | 7 | 2735902.4413 | 0.4859 | 0.2185 | nan | nan |
| lstm | 0.4026 | 4.6215 | 0.0223 | 0.4195 | 9053316.0500 | 159.8597 | -0.0168 | 200 | lstm | sklearn_mlp_lstm_surrogate | TRUE | lstm (fallback) | 8 | 8 | 963856.4934 | 0.3985 | 0.2040 | nan | nan |